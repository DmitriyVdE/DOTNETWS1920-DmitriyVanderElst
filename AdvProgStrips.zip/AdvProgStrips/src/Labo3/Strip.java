package Labo3;

import java.util.Objects;

public class Strip implements Comparable<Strip> {
    private String reeksnaam;
    private String titel;
    private int reeksnummer;
    private String tekenaar;
    private String schrijver;
    private String Uitgever;

    public Strip() {

    }

    public Strip(String reeksnaam, String tekenaar, String schrijver, String uitgever, int reeksnummer, String titel) {
        this.reeksnaam = reeksnaam;
        this.titel = titel;
        this.reeksnummer = reeksnummer;
        this.tekenaar = tekenaar;
        this.schrijver = schrijver;
        this.Uitgever = uitgever;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Strip strip = (Strip) o;
        return reeksnummer == strip.reeksnummer &&
                reeksnaam.equals(strip.reeksnaam) &&
                titel.equals(strip.titel) &&
                tekenaar.equals(strip.tekenaar) &&
                schrijver.equals(strip.schrijver) &&
                Uitgever.equals(strip.Uitgever);
    }

    @Override
    public int hashCode() {
        return Objects.hash(reeksnaam, titel, reeksnummer, tekenaar, schrijver, Uitgever);
    }


    public String getReeksnaam() {
        return reeksnaam;
    }

    public void setReeksnaam(String reeksnaam) {
        this.reeksnaam = reeksnaam;
    }

    public String getTitel() {
        return titel;
    }

    public void setTitel(String titel) {
        this.titel = titel;
    }

    public int getReeksnummer() {
        return reeksnummer;
    }

    public void setReeksnummer(int reeksnummer) {
        this.reeksnummer = reeksnummer;
    }

    public String getTekenaar() {
        return tekenaar;
    }

    public void setTekenaar(String tekenaar) {
        this.tekenaar = tekenaar;
    }

    public String getSchrijver() {
        return schrijver;
    }

    public void setSchrijver(String schrijver) {
        this.schrijver = schrijver;
    }

    public String getUitgever() {
        return Uitgever;
    }

    public void setUitgever(String uitgever) {
        Uitgever = uitgever;
    }

    @Override
    public int compareTo(Strip that) {
        /*
        if (this.reeksnaam.compareTo(that.reeksnaam) < 0) {
            return -1;
        } else if (this.reeksnaam.compareTo(that.reeksnaam) > 0) {
            return 1;
        }

        if (this.titel.compareTo(that.titel) < 0) {
            return -1;
        } else if (this.titel.compareTo(that.titel) > 0) {
            return 1;
        }
        /**/

        if (this.reeksnummer < that.reeksnummer) {
            return -1;
        } else if (this.reeksnummer > that.reeksnummer) {
            return 1;
        }
        return 0;
    }
}
