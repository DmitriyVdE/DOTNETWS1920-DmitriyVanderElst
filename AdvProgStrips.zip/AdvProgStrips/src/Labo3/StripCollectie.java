package Labo3;

import java.util.Arrays;
import java.util.HashMap;
import java.util.stream.Stream;

public class StripCollectie implements IStripCollectie {

    private Strip[] strips;

    public StripCollectie() {
        this.strips = new Strip[0];
    }

    public Strip[] getStrips(String reeks) {
        HashMap<String, Strip[]> stripshashmap = new HashMap<String, Strip[]>();

        for(int i = 0; i < strips.length; i++) {
            if (stripshashmap.containsKey(strips[i].getReeksnaam())) {
                Strip[] temp = stripshashmap.get(strips[i].getReeksnaam());

                Strip[] temp2 = new Strip[temp.length + 1];

                for(int j = 0; j < temp.length; j++) {
                    temp2[j] = temp[j];
                }

                temp2[temp2.length - 1] = strips[i];

                stripshashmap.replace(strips[i].getReeksnaam(), temp2);
            } else {
                Strip[] temp3 = new Strip[]{ strips[i]};
                stripshashmap.put(strips[i].getReeksnaam(), temp3);
            }
        }

        return stripshashmap.get(reeks);
    }


    public void verwijder(Strip strip) {
        if (strips.length > 0) {
            int pos = 0;
            for(int i = 0; i < this.strips.length; i++) {
                if (strips[i].equals(strip)){
                    pos = i;
                }
            }

            Strip[] a = Arrays.copyOfRange(strips, 0, pos);
            Strip[] b = Arrays.copyOfRange(strips, pos + 1, strips.length);

            strips = Stream.of(a, b).flatMap(Stream::of).toArray(Strip[]::new);
        }
        sorteerStrips();
    }


    public void voegToe(Strip strip) {

        for(int i = 0; i < this.strips.length; i++) {
            if (strips[i].equals(strip)){
                return;
            }
        }

        Strip[] temp = new Strip[this.strips.length + 1];

        for(int i = 0; i < this.strips.length; i++) {
            temp[i] = strips[i];
        }

        temp[temp.length - 1] = strip;

        this.strips = temp;
        sorteerStrips();
    }

    private void sorteerStrips() {
        Arrays.sort(strips);
    }
}
