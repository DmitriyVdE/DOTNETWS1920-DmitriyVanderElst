package Labo3;

public class Main {
    public static void main (String[] args) {
        StripCollectie stripcol = new StripCollectie();
        //stripcol.stripMaker().get().forEach(x -> System.out.println(x.getReeksnaam()));

        stripcol.stripMaker().get()
                .sorted (( Strip s1 , Strip  s2) -> {
                    int reeksComp = s1.getReeksnaam().compareTo(s2.getReeksnaam());
                    if (reeksComp == 0) {
                        return s1.compareTo(s2);
                    }
                    else return reeksComp;
                }).forEach(System.out::println);

        stripcol.stripMaker().get()
                .sorted (( Strip s1 , Strip  s2) -> {
                    int uitgeverijComp = s1.getUitgever().compareTo(s2.getUitgever());
                    if (uitgeverijComp == 0) {
                        int reeksComp = s1.getReeksnaam().compareTo(s2.getReeksnaam());
                        if (reeksComp == 0) {
                            return s1.compareTo(s2);
                        }
                        else return reeksComp;
                    }
                    else return uitgeverijComp;
                }).forEach(System.out::println);

        stripcol.stripMaker().get()
                .sorted (( Strip s1 , Strip  s2) -> {
                    if (s1.getTekenaar().equals(s2.getTekenaar())) {
                        if (s1.getReeksnaam().equals(s2.getReeksnaam())) {
                            return s1.getTitel().compareTo(s2.getTitel());
                        }
                        else return s1.getReeksnaam().compareTo(s2.getReeksnaam());
                    }
                    else return s1.getTekenaar().compareTo(s2.getTekenaar());
                }).forEach(System.out::println);
    }
}
